
# Simple CLI client for testing the chat API
import requests, time, os

API = os.getenv('CHATBOT_API','http://localhost:8000')

def chat(text, session_id=None):
    payload = {'text': text}
    if session_id: payload['session_id'] = session_id
    r = requests.post(API + '/chat', json=payload, timeout=10)
    r.raise_for_status()
    j = r.json()
    for m in j['messages']:
        print(f"{m['role'].upper()}: {m['text']}")
    return j['session_id']

if __name__ == '__main__':
    sid = None
    sid = chat('Hi there')
    time.sleep(0.4)
    sid = chat('Track my order SO-10492 alex@example.com', session_id=sid)
    time.sleep(0.4)
    sid = chat('I want to start a return', session_id=sid)
