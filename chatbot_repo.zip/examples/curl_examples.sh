
# Example curl commands
curl -X POST http://localhost:8000/chat -H 'Content-Type: application/json' -d '{"text":"Hi"}'

curl -X POST http://localhost:8000/chat -H 'Content-Type: application/json' -d '{"text":"Track my order SO-10492 alex@example.com"}'

curl -X POST 'http://localhost:8000/handoff?session_id=<SESSION_ID>&mode=email&subject=Please%20help'

curl http://localhost:8000/transcript/<SESSION_ID>

