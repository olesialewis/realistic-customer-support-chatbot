
# Realistic Customer Support Chatbot (Python / FastAPI)

This repository contains a realistic customer-support chatbot implemented in **Python** using **FastAPI**.
It includes:
- Intent detection & entity extraction (rule-based, regex)
- Mock order database and order lookup flows
- Context-aware multi-turn conversations with session memory
- Human handoff (creates a ticket stub)
- CSAT / rating capture and transcript export
- Optional integration with OpenAI (LLM) for richer responses (configurable via environment variable)

## What's included
- `app/main.py` - FastAPI app with endpoints for chat and admin actions.
- `app/nlp.py` - Intent detection, entity extraction, helper utilities.
- `app/db.py` - Mock order DB and ticket store (in-memory, easy to replace with real DB).
- `app/schemas.py` - Pydantic schemas.
- `Dockerfile`, `requirements.txt`
- `examples/` - example curl requests and a simple local client `cli_client.py`.

## Quick start (local)

1. Create a virtualenv:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. Run the app:
   ```bash
   uvicorn app.main:app --reload --port 8000
   ```

3. Open the interactive docs: http://localhost:8000/docs

## Optional: Enable OpenAI responses
Set `OPENAI_API_KEY` environment variable. The app will use the OpenAI API to generate fallback responses
and make replies more human-like. Without it, the bot uses high-quality deterministic templates and rules.

## Deploying to GitHub
1. Create a new repo on GitHub.
2. From this folder run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - realistic chatbot"
   git branch -M main
   git remote add origin <your-github-remote-url>
   git push -u origin main
   ```

## Notes
- This project is intentionally framework-agnostic for the NLP piece — replace `app/nlp.py` with your own model (Rasa, spaCy, LLM pipeline).
- For production, replace in-memory stores with a persistent DB and add authentication.
