
from pydantic import BaseModel, Field
from typing import Optional, List, Dict

class ChatRequest(BaseModel):
    session_id: Optional[str] = None
    text: str

class ChatMessage(BaseModel):
    role: str
    text: str
    meta: Optional[Dict] = None

class ChatResponse(BaseModel):
    messages: List[ChatMessage]
    session_id: str

class Ticket(BaseModel):
    ticket_id: str
    session_id: Optional[str]
    subject: str
    details: str
    status: str = 'open'
