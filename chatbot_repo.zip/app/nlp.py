
import re
from typing import Optional, Dict, Any
import random

INTENTS = ['greeting','order_status','return_refund','shipping_info','cancel_order','product_info','connect_agent','goodbye','smalltalk','fallback']

def detect_intent(text: str) -> str:
    t = text.lower()
    if re.search(r"\b(hi|hello|hey|good morning|good afternoon|good evening)\b", t): return 'greeting'
    if re.search(r"\b(order|track|status|tracking|where.*package)\b", t): return 'order_status'
    if re.search(r"\b(return|refund|exchange|wrong size|doesn't fit|doesnt fit)\b", t): return 'return_refund'
    if re.search(r"\b(ship|shipping|delivery|arrive|when.*arrive)\b", t): return 'shipping_info'
    if re.search(r"\b(cancel|cancellation|cancelation)\b", t): return 'cancel_order'
    if re.search(r"\b(agent|human|representative|someone|talk to|call)\b", t): return 'connect_agent'
    if re.search(r"\b(thank|thanks|bye|goodbye)\b", t): return 'goodbye'
    if re.search(r"\b(how are you|what's up|who are you|joke)\b", t): return 'smalltalk'
    # product queries
    if re.search(r"\b(size|fit|material|waterproof|compare|product)\b", t): return 'product_info'
    return 'fallback'

def extract_order_id(text: str) -> Optional[str]:
    m = re.search(r"\b([A-Z]{2}-\d{5})\b", text, re.IGNORECASE)
    return m.group(1).upper() if m else None

def extract_email(text: str) -> Optional[str]:
    m = re.search(r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}", text, re.IGNORECASE)
    return m.group(0).lower() if m else None

def templated_reply(intent: str, slots: Dict[str, Any]) -> str:
    # deterministic friendly templates for each intent
    if intent == 'greeting':
        return random.choice(["Hi — I'm Skyline Support. How can I help today?","Hello! I can help with orders, returns, or product questions."])
    if intent == 'order_status':
        if not slots.get('orderId') or not slots.get('email'):
            return "I can look that up — could you share your order ID (e.g., SO-10492) and the email used at checkout?"
        return "Let me pull up that order for you — one moment please."
    if intent == 'return_refund':
        return "No problem — our policy allows returns within 30 days of delivery if items are unworn with tags. Want me to create a prepaid return label for your most recent order?"
    if intent == 'shipping_info':
        return "Standard shipping is 3-5 business days. Orders placed before 2pm PT often ship same-day."
    if intent == 'cancel_order':
        return "I can try to cancel the order if it hasn't shipped yet — can you share the order ID and email?"
    if intent == 'product_info':
        return "Tell me which product you're looking at and I can provide sizing, materials, and comparisons."
    if intent == 'connect_agent':
        return "I can connect you to a human agent — would you prefer a call or an email?"
    if intent == 'goodbye':
        return "Thanks for chatting — have a great day!"
    if intent == 'smalltalk':
        return random.choice(["I'm doing great, thanks! How can I help?","All good here — what can I do for you today?"])
    return "Sorry — I didn't quite catch that. Could you rephrase or give more details?"
