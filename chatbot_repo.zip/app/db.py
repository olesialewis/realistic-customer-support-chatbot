
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import uuid

# Mock orders
MOCK_ORDERS = [
    {
        'orderId': 'SO-10492',
        'email': 'alex@example.com',
        'status': 'In Transit',
        'carrier': 'UPS',
        'tracking': '1Z999AA10123456784',
        'eta': (datetime.utcnow() + timedelta(days=2)).isoformat(),
        'items': [{'sku': 'JKT-ALP-XL', 'name': 'Alpine Shell Jacket', 'size': 'XL', 'qty': 1}],
        'total': 168.49,
        'address': '123 Oak Street, Denver, CO 80203',
        'placedAt': (datetime.utcnow() - timedelta(days=3)).isoformat()
    },
    {
        'orderId': 'SO-10531',
        'email': 'olesia@example.com',
        'status': 'Delivered',
        'carrier': 'USPS',
        'tracking': '9400111899564561234567',
        'eta': (datetime.utcnow() - timedelta(days=1)).isoformat(),
        'items': [{'sku': 'PNT-TRK-S', 'name': 'Trail Pants', 'size': 'S', 'qty': 1}],
        'total': 79.99,
        'address': '2330 N 7th St, Phoenix, AZ 85006',
        'placedAt': (datetime.utcnow() - timedelta(days=6)).isoformat()
    },
]

# In-memory session store and tickets
SESSIONS: Dict[str, Dict] = {}
TICKETS: Dict[str, Dict] = {}

def find_order(order_id: str, email: str) -> Optional[Dict]:
    for o in MOCK_ORDERS:
        if o['orderId'].upper() == order_id.upper() and o['email'].lower() == email.lower():
            return o
    return None

def create_session(session_id: str) -> Dict:
    s = SESSIONS.get(session_id)
    if s: return s
    SESSIONS[session_id] = {'createdAt': datetime.utcnow().isoformat(), 'messages': []}
    return SESSIONS[session_id]

def append_message(session_id: str, role: str, text: str, meta: dict = None):
    s = create_session(session_id)
    s['messages'].append({'role': role, 'text': text, 'meta': meta or {}, 'at': datetime.utcnow().isoformat()})

def create_ticket(session_id: str, subject: str, details: str) -> Dict:
    ticket_id = 'T-' + uuid.uuid4().hex[:8].upper()
    t = {'ticket_id': ticket_id, 'session_id': session_id, 'subject': subject, 'details': details, 'status': 'open', 'createdAt': datetime.utcnow().isoformat()}
    TICKETS[ticket_id] = t
    return t
