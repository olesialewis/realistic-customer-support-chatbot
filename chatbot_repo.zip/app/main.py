
from fastapi import FastAPI, HTTPException
from app.schemas import ChatRequest, ChatResponse, ChatMessage, Ticket
from app import nlp, db
import uuid, os, asyncio, httpx

app = FastAPI(title='Realistic Customer Support Chatbot (FastAPI)')

OPENAI_KEY = os.getenv('OPENAI_API_KEY')

def make_session_id() -> str:
    return uuid.uuid4().hex

@app.post('/chat', response_model=ChatResponse)
async def chat(req: ChatRequest):
    session_id = req.session_id or make_session_id()
    db.create_session(session_id)
    # append user message
    db.append_message(session_id, 'user', req.text)

    # NLP
    intent = nlp.detect_intent(req.text)
    order_id = nlp.extract_order_id(req.text)
    email = nlp.extract_email(req.text)
    slots = {'orderId': order_id, 'email': email}

    # If order status intent and we have slots - try lookup
    messages = []
    if intent == 'order_status' and order_id and email:
        order = db.find_order(order_id, email)
        if order:
            reply = f"Found order {order['orderId']}: status={order['status']}, carrier={order['carrier']}, tracking={order['tracking']}, ETA={order['eta']}\nItems: {', '.join([i['name'] for i in order['items']])}"
            messages.append({'role':'assistant','text':reply})
            db.append_message(session_id, 'assistant', reply, {'intent':'order_status','order':order})
            return {'messages':[ChatMessage(**m) for m in messages], 'session_id': session_id}
        else:
            reply = "I couldn't find that order with the email provided. Could you double-check the order ID and email?"
            messages.append({'role':'assistant','text':reply})
            db.append_message(session_id, 'assistant', reply, {'intent':'order_status','found':False})
            return {'messages':[ChatMessage(**m) for m in messages], 'session_id': session_id}

    # Otherwise: template reply
    reply = nlp.templated_reply(intent, slots)
    messages.append({'role':'assistant','text':reply})
    db.append_message(session_id, 'assistant', reply, {'intent': intent})

    # If fallback and OpenAI key present, call OpenAI for an enriched reply (non-blocking style - but here we'll await)
    if intent == 'fallback' and OPENAI_KEY:
        # Use OpenAI to generate a helpful response (optional). We'll call the completions endpoint via httpx.
        prompt = f"You are a friendly customer support assistant for Skyline Outfitters. User: {req.text}\nAssistant:"
        headers = {'Authorization': f'Bearer {OPENAI_KEY}'}
        data = {'model':'gpt-4o-mini', 'prompt': prompt, 'max_tokens': 200}
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                r = await client.post('https://api.openai.com/v1/completions', headers=headers, json=data)
                jr = r.json()
                # Best-effort parsing; users should adapt to OpenAI response shape.
                text = jr.get('choices',[{}])[0].get('text') if jr.get('choices') else None
                if text:
                    messages = [{'role':'assistant','text': text.strip()}]
                    db.append_message(session_id, 'assistant', text.strip(), {'intent':'fallback','llm':True})
                    return {'messages':[ChatMessage(**m) for m in messages], 'session_id': session_id}
        except Exception as e:
            # ignore and fall back to templated reply (we already added it)
            pass

    return {'messages':[ChatMessage(**m) for m in messages], 'session_id': session_id}

@app.post('/handoff', response_model=Ticket)
async def handoff(session_id: str, mode: str = 'email', subject: str = 'Customer request'):
    # Create a ticket for human agents
    s = db.SESSIONS.get(session_id)
    if not s:
        raise HTTPException(status_code=404, detail='session not found')
    details = '\n'.join([f"[{m['role']}] {m['text']}" for m in s['messages'][-20:]])
    t = db.create_ticket(session_id, subject, details)
    return t

@app.get('/transcript/{session_id}')
async def transcript(session_id: str):
    s = db.SESSIONS.get(session_id)
    if not s:
        raise HTTPException(status_code=404, detail='session not found')
    return {'session_id': session_id, 'messages': s['messages']}
